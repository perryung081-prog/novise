CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','locked')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL UNIQUE REFERENCES users(id),
  network TEXT NOT NULL DEFAULT 'TRON_MAINNET',
  asset TEXT NOT NULL DEFAULT 'USDT',
  deposit_address TEXT UNIQUE,
  address_status TEXT NOT NULL DEFAULT 'pending_provider_setup'
    CHECK (address_status IN ('pending_provider_setup','active','disabled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  asset TEXT NOT NULL DEFAULT 'USDT',
  amount NUMERIC(30,6) NOT NULL,
  entry_type TEXT NOT NULL CHECK (entry_type IN ('deposit','withdrawal','adjustment')),
  status TEXT NOT NULL CHECK (status IN ('pending','confirmed','rejected')),
  external_ref TEXT UNIQUE,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id),
  asset TEXT NOT NULL DEFAULT 'USDT',
  amount NUMERIC(30,6) NOT NULL CHECK (amount > 0),
  destination_address TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_review'
    CHECK (status IN ('pending_review','approved','broadcast','completed','rejected')),
  txid TEXT UNIQUE,
  reviewed_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ledger_user_created_idx ON ledger_entries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawal_user_created_idx ON withdrawal_requests(user_id, created_at DESC);
