# NOVISE — custodial USDT TRC20 platform starter

This is a backend foundation, **not a production-ready exchange and not yet connected to a custody provider**. It includes:
- customer registration and login
- PostgreSQL schema for customers, individual wallet records, a transaction ledger, and withdrawal requests
- authenticated balance and transaction-history endpoints
- admin overview endpoint
- security middleware, request limits, password hashing, and short-lived JWTs

## What is intentionally not enabled
- No wallet private keys or seed phrases are generated or stored.
- No real deposit address is invented or assigned.
- No deposit is credited based on a screenshot or client request.
- No withdrawal is broadcast.
- No fake balances are created.

A real custodial launch needs a reviewed custody/key-management provider or audited HSM/MPC setup, TRON mainnet deposit monitoring for the official USDT contract, idempotent confirmation handling, reconciliation, withdrawal signing policy, multi-factor authentication, audit logs, backups, monitoring, incident response, and a legal/compliance review for the operating jurisdiction.

## Run locally
1. Install Node.js 20+ and PostgreSQL.
2. Create a database named `novise`.
3. Run the schema: `psql "$DATABASE_URL" -f schema.sql`
4. Copy `.env.example` to `.env`, set `DATABASE_URL`, and create a random `JWT_SECRET` of 32+ characters.
5. Run `npm install`, then `npm start`.

The API listens on `http://localhost:3000`. `GET /health` checks that it is running.

## Important admin setup
The registration route only creates `customer` accounts. Do not make an admin by editing a public request or adding a role field to registration. Create the first admin through a controlled database migration or secure one-time provisioning script, with strong MFA added before deployment.

## API endpoints
- `POST /api/auth/register` — `{ "email": "...", "password": "at least 12 characters" }`
- `POST /api/auth/login` — returns a short-lived bearer token
- `GET /api/me` — authenticated profile and wallet provisioning status
- `GET /api/balance` — confirmed ledger balance
- `GET /api/transactions` — last 100 ledger entries
- `POST /api/withdrawals` — `{ "amount": "10.00", "destination_address": "T..." }`; creates a review request only
- `GET /api/admin/overview` — admin-only totals

## Before real customer funds
Have an experienced blockchain security engineer review the design. Never put seed phrases/private keys in HTML, browser storage, source control, chat, or a normal `.env` file. Do not accept customer deposits until real address provisioning, chain-confirmed deposits, ledger reconciliation, withdrawal signing controls, monitoring, and applicable regulatory obligations are complete.
