require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Pool } = require("pg");

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const PORT = Number(process.env.PORT || 3000);

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random secret of at least 32 characters.");
  process.exit(1);
}

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false }));

function auth(requiredRole) {
  return (req, res, next) => {
    const raw = req.headers.authorization || "";
    const token = raw.startsWith("Bearer ") ? raw.slice(7) : "";
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      req.user = payload;
      if (requiredRole && payload.role !== requiredRole) return res.status(403).json({ error: "Forbidden" });
      next();
    } catch {
      return res.status(401).json({ error: "Authentication required" });
    }
  };
}
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

app.get("/health", (req, res) => res.json({ ok: true, service: "NOVISE API", mode: "starter" }));

app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email) || password.length < 12) {
    return res.status(400).json({ error: "Provide a valid email and a password of at least 12 characters." });
  }
  const passwordHash = await bcrypt.hash(password, 12);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const inserted = await client.query(
      "INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email,role,created_at",
      [email, passwordHash]
    );
    const user = inserted.rows[0];
    // Address provisioning is deliberately not faked. Integrate an audited custody provider here.
    await client.query("INSERT INTO wallets(user_id) VALUES($1)", [user.id]);
    await client.query("COMMIT");
    res.status(201).json({
      user,
      wallet: { network: "TRON_MAINNET", asset: "USDT", deposit_address: null, address_status: "pending_provider_setup" },
      notice: "A real deposit address appears only after a custody/address provider is securely configured."
    });
  } catch (e) {
    await client.query("ROLLBACK");
    if (e.code === "23505") return res.status(409).json({ error: "An account with that email already exists." });
    throw e;
  } finally { client.release(); }
}));

app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const result = await pool.query("SELECT id,email,password_hash,role,status FROM users WHERE email=$1", [email]);
  const user = result.rows[0];
  if (!user || user.status !== "active" || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Invalid credentials." });
  }
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: "30m" });
  res.json({ token, user: { id: user.id, email: user.email, role: user.role } });
}));

app.get("/api/me", auth(), asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT u.id,u.email,u.role,u.created_at,w.network,w.asset,w.deposit_address,w.address_status " +
    "FROM users u JOIN wallets w ON w.user_id=u.id WHERE u.id=$1", [req.user.id]
  );
  if (!result.rows[0]) return res.status(404).json({ error: "User not found." });
  res.json(result.rows[0]);
}));

app.get("/api/balance", auth(), asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT COALESCE(SUM(CASE WHEN status='confirmed' AND entry_type='deposit' THEN amount " +
    "WHEN status='confirmed' AND entry_type='withdrawal' THEN -amount ELSE 0 END),0)::text AS available_usdt " +
    "FROM ledger_entries WHERE user_id=$1", [req.user.id]
  );
  res.json({ asset: "USDT", network: "TRON_MAINNET", available: result.rows[0].available_usdt });
}));

app.get("/api/transactions", auth(), asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT id,asset,amount,entry_type,status,external_ref,note,created_at FROM ledger_entries " +
    "WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100", [req.user.id]
  );
  res.json({ transactions: result.rows });
}));

app.post("/api/withdrawals", auth(), asyncRoute(async (req, res) => {
  const amount = String(req.body.amount || "");
  const destination = String(req.body.destination_address || "").trim();
  if (!/^\d+(\.\d{1,6})?$/.test(amount) || Number(amount) <= 0 || !/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(destination)) {
    return res.status(400).json({ error: "Enter a positive USDT amount (up to 6 decimals) and a valid-looking TRON address." });
  }
  const result = await pool.query(
    "INSERT INTO withdrawal_requests(user_id,amount,destination_address) VALUES($1,$2,$3) " +
    "RETURNING id,asset,amount,destination_address,status,created_at",
    [req.user.id, amount, destination]
  );
  res.status(201).json({
    withdrawal: result.rows[0],
    notice: "Request submitted for review. This starter does not broadcast blockchain transactions."
  });
}));

app.get("/api/admin/overview", auth("admin"), asyncRoute(async (req, res) => {
  const [users, deposits, withdrawals] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS count FROM users WHERE role='customer'"),
    pool.query("SELECT COALESCE(SUM(amount),0)::text AS total FROM ledger_entries WHERE entry_type='deposit' AND status='confirmed'"),
    pool.query("SELECT COUNT(*)::int AS pending FROM withdrawal_requests WHERE status='pending_review'")
  ]);
  res.json({ customers: users.rows[0].count, confirmed_deposits_usdt: deposits.rows[0].total, pending_withdrawals: withdrawals.rows[0].pending });
}));

// No endpoint here can credit deposits or approve/broadcast withdrawals.
// Those actions must be implemented only after verified chain monitoring and custody-provider integration.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error." });
});

app.listen(PORT, () => console.log(`NOVISE API listening on port ${PORT}`));
